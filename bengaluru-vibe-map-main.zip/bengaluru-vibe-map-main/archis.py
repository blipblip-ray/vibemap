from datetime import datetime
from enum import Enum
from typing import Optional, List, Tuple, Union
import uuid
from pydantic import BaseModel, Field, validator

class SourceType(str, Enum):
    BUSINESS = "BUSINESS"
    AUTHORITY = "AUTHORITY"
    USER = "USER"
    OTHER = "OTHER"

class ReportType(str, Enum):
    PAST_EVENT = "PAST_EVENT"
    CURRENT_EVENT = "CURRENT_EVENT"
    FUTURE_EVENT = "FUTURE_EVENT"

class Priority(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    NA = "NA"

class VerificationStatus(str, Enum):
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    VERIFIED = "VERIFIED"

# Topics configuration
TOPICS_CONFIG = {
    "authority": ["traffic", "emergency", "civic", "infrastructure", "safety"],
    "business": ["opening", "closing", "promotion", "service", "hiring"],
    "community": ["event", "gathering", "celebration", "protest", "meeting"],
    "health": ["medical", "wellness", "epidemic", "health_alert"],
    "transport": [
        "metro",
        "bus",
        "traffic",
        "parking",
        "road_closure",
        "air_transport",
    ],
    "utility": ["power", "water", "internet", "maintenance"],
    "weather": ["rain", "flood", "heat_wave", "storm", "aqi"],
    "dining": ["new_restaurant", "food_festival", "offers", "reviews"],
    "entertainment": ["movie", "concert", "theater", "sports"],
}

ALL_TOPICS = [topic for topics_list in TOPICS_CONFIG.values() for topic in topics_list]

# Pydantic Models
class Location(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)

class IngestRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    source_type: SourceType
    source_id: str
    text: Optional[str] = None
    reported_from_location: Optional[Location] = None
    reported_at_timestamp: Optional[datetime] = Field(default_factory=datetime.utcnow)

    @validator("id")
    def validate_id(cls, v):
        try:
            uuid.UUID(v)
            return v
        except ValueError:
            raise ValueError("Invalid UUID format for id")

class FileMetadata(BaseModel):
    file_id: str
    file_type: str
    timestamp: Optional[datetime] = None
    location: Optional[Location] = None
    location_name: Optional[str] = None
    file_description: str

class TextMetadata(BaseModel):
    text: str
    original_language: str
    normalized_description: str
    location_names: List[str] = []
    locations: List[Location] = []
    datetime_mentions: List[Union[datetime, Tuple[datetime, datetime]]] = Field(
        default_factory=list
    )

class ReportMetadata(BaseModel):
    source_type: SourceType
    report_type: ReportType
    report_priority: Priority
    report_topics: List[str] = Field(default_factory=list)
    reported_at_timestamp: datetime
    reported_from_location: Location

class CheckMetadata(BaseModel):
    score: int = Field(..., ge=0, le=5)
    reason: str

class VerificationMetadata(BaseModel):
    status: VerificationStatus = VerificationStatus.PENDING
    reason: str
    validity_scores: int = Field(..., ge=0, le=125) # 5*5*5
    triviality_check_metadata: CheckMetadata
    location_datetime_check_metadata: CheckMetadata
    coherence_check_metadata: CheckMetadata

class HolisticSummary(BaseModel):
    id: str
    title: str
    details: str
    locations: List[Location]
    location_names: List[str]
    files: List[str] = Field(default_factory=list)
    topics: List[str]
    report_type: ReportType
    report_priority: Priority
    start_timestamp: datetime
    end_timestamp: datetime

class UrbanReport(BaseModel):
    id: str
    request: IngestRequest
    file_metadata: Optional[FileMetadata] = None
    text_metadata: Optional[TextMetadata] = None
    report_metadata: ReportMetadata
    verification_metadata: Optional[VerificationMetadata] = None
    holistic_summary: HolisticSummary

# 703b935455954ed8861349d648757dd6