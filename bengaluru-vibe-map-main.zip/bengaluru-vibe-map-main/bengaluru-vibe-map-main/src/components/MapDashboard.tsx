import { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';
import { database } from '@/lib/firebase';
import { ref, onValue, off } from 'firebase/database';
import MapPin from './MapPin';
import SearchInput from './SearchInput';
import ApiKeyInput from './ApiKeyInput';
import { Loader2, ChevronDown, ChevronUp } from 'lucide-react';
import { 
  UrbanReport, 
  SourceType, 
  ReportType, 
  Priority, 
  VerificationStatus,
  getPriorityColor,
  getReportTypeColor,
  getTopicCategory
} from '@/types/urbanReport';

// Bengaluru coordinates
const BENGALURU_CENTER: [number, number] = [77.5946, 12.9716];

// Demo data using UrbanReport structure
const DEMO_DATA: UrbanReport[] = [
  {
    id: '1',
    request: {
      id: '1',
      source_type: SourceType.AUTHORITY,
      source_id: 'traffic_dept_blr',
      text: 'Heavy traffic reported on MG Road due to construction work',
      reported_from_location: { latitude: 12.9716, longitude: 77.5946 },
      reported_at_timestamp: new Date(Date.now() - 300000)
    },
    report_metadata: {
      source_type: SourceType.AUTHORITY,
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.HIGH,
      report_topics: ['traffic', 'infrastructure'],
      reported_at_timestamp: new Date(Date.now() - 300000),
      reported_from_location: { latitude: 12.9716, longitude: 77.5946 }
    },
    holistic_summary: {
      id: '1',
      title: 'Heavy Traffic - MG Road',
      details: 'Traffic jam on MG Road due to ongoing construction work. Expect delays of 15-20 minutes.',
      locations: [{ latitude: 12.9716, longitude: 77.5946 }],
      location_names: ['MG Road', 'Brigade Road Junction'],
      files: [],
      topics: ['traffic', 'infrastructure'],
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.HIGH,
      start_timestamp: new Date(Date.now() - 300000),
      end_timestamp: new Date(Date.now() + 3600000)
    }
  },
  {
    id: '2',
    request: {
      id: '2',
      source_type: SourceType.BUSINESS,
      source_id: 'palace_grounds_events',
      text: 'Bengaluru Literature Festival ongoing at Palace Grounds',
      reported_from_location: { latitude: 12.9352, longitude: 77.6245 },
      reported_at_timestamp: new Date(Date.now() - 1800000)
    },
    report_metadata: {
      source_type: SourceType.BUSINESS,
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      report_topics: ['event', 'gathering', 'entertainment'],
      reported_at_timestamp: new Date(Date.now() - 1800000),
      reported_from_location: { latitude: 12.9352, longitude: 77.6245 }
    },
    holistic_summary: {
      id: '2',
      title: 'Bengaluru Literature Festival',
      details: 'Annual literature festival featuring renowned authors, book readings, and cultural performances.',
      locations: [{ latitude: 12.9352, longitude: 77.6245 }],
      location_names: ['Palace Grounds'],
      files: [],
      topics: ['event', 'gathering', 'entertainment'],
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      start_timestamp: new Date(Date.now() - 1800000),
      end_timestamp: new Date(Date.now() + 7200000)
    }
  },
  {
    id: '3',
    request: {
      id: '3',
      source_type: SourceType.AUTHORITY,
      source_id: 'bbmp_works',
      text: 'Temporary road closure on Whitefield Road for emergency repairs',
      reported_from_location: { latitude: 12.9579, longitude: 77.6411 },
      reported_at_timestamp: new Date(Date.now() - 3600000)
    },
    report_metadata: {
      source_type: SourceType.AUTHORITY,
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      report_topics: ['safety', 'infrastructure', 'road_closure'],
      reported_at_timestamp: new Date(Date.now() - 3600000),
      reported_from_location: { latitude: 12.9579, longitude: 77.6411 }
    },
    holistic_summary: {
      id: '3',
      title: 'Road Closure - Whitefield Road',
      details: 'Temporary road closure on Whitefield Road for emergency water pipe repairs. Alternative routes available.',
      locations: [{ latitude: 12.9579, longitude: 77.6411 }],
      location_names: ['Whitefield Road', 'ITPL Main Road'],
      files: [],
      topics: ['safety', 'infrastructure', 'road_closure'],
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      start_timestamp: new Date(Date.now() - 3600000),
      end_timestamp: new Date(Date.now() + 10800000)
    }
  },
  {
    id: '4',
    request: {
      id: '4',
      source_type: SourceType.AUTHORITY,
      source_id: 'bmrcl_ops',
      text: 'Purple line metro experiencing delays due to technical issues',
      reported_from_location: { latitude: 12.9780, longitude: 77.5909 },
      reported_at_timestamp: new Date(Date.now() - 900000)
    },
    report_metadata: {
      source_type: SourceType.AUTHORITY,
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      report_topics: ['metro', 'transport'],
      reported_at_timestamp: new Date(Date.now() - 900000),
      reported_from_location: { latitude: 12.9780, longitude: 77.5909 }
    },
    holistic_summary: {
      id: '4',
      title: 'Metro Delay - Purple Line',
      details: 'Purple line experiencing 10-minute delays due to technical issues at Cubbon Park station.',
      locations: [{ latitude: 12.9780, longitude: 77.5909 }],
      location_names: ['Cubbon Park Metro Station', 'Purple Line'],
      files: [],
      topics: ['metro', 'transport'],
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.MEDIUM,
      start_timestamp: new Date(Date.now() - 900000),
      end_timestamp: new Date(Date.now() + 1800000)
    }
  },
  {
    id: '5',
    request: {
      id: '5',
      source_type: SourceType.AUTHORITY,
      source_id: 'bescom_ops',
      text: 'Scheduled power maintenance in HSR Layout area',
      reported_from_location: { latitude: 12.9266, longitude: 77.6277 },
      reported_at_timestamp: new Date(Date.now() - 2700000)
    },
    report_metadata: {
      source_type: SourceType.AUTHORITY,
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.LOW,
      report_topics: ['power', 'maintenance'],
      reported_at_timestamp: new Date(Date.now() - 2700000),
      reported_from_location: { latitude: 12.9266, longitude: 77.6277 }
    },
    holistic_summary: {
      id: '5',
      title: 'Power Maintenance - HSR Layout',
      details: 'Scheduled maintenance affecting HSR Layout area. Power will be restored by 6 PM.',
      locations: [{ latitude: 12.9266, longitude: 77.6277 }],
      location_names: ['HSR Layout', 'Sector 1', 'Sector 2'],
      files: [],
      topics: ['power', 'maintenance'],
      report_type: ReportType.CURRENT_EVENT,
      report_priority: Priority.LOW,
      start_timestamp: new Date(Date.now() - 2700000),
      end_timestamp: new Date(Date.now() + 5400000)
    }
  }
];

const MapDashboard = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const [mapData, setMapData] = useState<UrbanReport[]>(DEMO_DATA);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [googleMapsApiKey, setGoogleMapsApiKey] = useState<string | null>(null);
  const [isEventsExpanded, setIsEventsExpanded] = useState(true);

  // Check for existing API key on component mount
  useEffect(() => {
    const savedApiKey = localStorage.getItem('googleMapsApiKey');
    if (savedApiKey) {
      setGoogleMapsApiKey(savedApiKey);
    } else {
      setIsLoading(false);
    }
  }, []);

  // Initialize Google Maps
  useEffect(() => {
    if (!googleMapsApiKey || !mapContainer.current) return;

    const initMap = async () => {
      try {
        const loader = new Loader({
          apiKey: googleMapsApiKey,
          version: 'weekly',
          libraries: ['places']
        });

        const { Map } = await loader.importLibrary('maps');
        const { AdvancedMarkerElement } = await loader.importLibrary('marker');

        // Initialize map
        map.current = new Map(mapContainer.current!, {
          center: { lat: BENGALURU_CENTER[1], lng: BENGALURU_CENTER[0] },
          zoom: 11,
          mapId: 'bengaluru-dashboard', // Required for advanced markers
          tilt: 45,
          heading: 0
        });

        // Clear existing markers
        markersRef.current.forEach(marker => {
          if (marker.map) {
            marker.map = null;
          }
        });
        markersRef.current = [];

        // Add markers for map data
        mapData.forEach((report) => {
          if (map.current && report.holistic_summary.locations.length > 0) {
            const location = report.holistic_summary.locations[0];
            const priorityColor = getPriorityColor(report.holistic_summary.report_priority);
            
            // Create custom marker element with priority-based color
            const markerElement = document.createElement('div');
            markerElement.innerHTML = `
              <div class="relative w-12 h-12 rounded-full border-3 border-white shadow-floating cursor-pointer transition-all duration-300 ${priorityColor} flex items-center justify-center hover:scale-110">
                <div class="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                  <div class="w-3 h-3 ${priorityColor} rounded-full"></div>
                </div>
              </div>
            `;

            const marker = new AdvancedMarkerElement({
              map: map.current,
              position: { lat: location.latitude, lng: location.longitude },
              content: markerElement,
              title: report.holistic_summary.title
            });

            // Add click listener for marker
            markerElement.addEventListener('click', () => {
              const timeAgo = Math.floor((Date.now() - report.holistic_summary.start_timestamp.getTime()) / 1000 / 60);
              const sourceType = report.report_metadata.source_type;
              const priority = report.holistic_summary.report_priority;
              const topics = report.holistic_summary.topics.join(', ');
              
              // Create rich info window content
              const infoContent = `
                <div class="p-4 max-w-sm">
                  <div class="flex items-center gap-2 mb-2">
                    <h3 class="font-semibold text-base">${report.holistic_summary.title}</h3>
                    <span class="px-2 py-1 text-xs rounded-full ${getPriorityColor(priority)} text-white">${priority}</span>
                  </div>
                  <p class="text-sm text-gray-700 mb-3">${report.holistic_summary.details}</p>
                  <div class="space-y-1 text-xs text-gray-600">
                    <div><strong>Source:</strong> ${sourceType}</div>
                    <div><strong>Topics:</strong> ${topics}</div>
                    <div><strong>Locations:</strong> ${report.holistic_summary.location_names.join(', ')}</div>
                    <div><strong>Reported:</strong> ${timeAgo}m ago</div>
                  </div>
                </div>
              `;
              
              const infoWindow = new google.maps.InfoWindow({
                content: infoContent
              });
              
              infoWindow.open(map.current, marker);
            });

            markersRef.current.push(marker);
          }
        });

        setIsLoading(false);
      } catch (error) {
        console.error('Error loading Google Maps:', error);
        setIsLoading(false);
      }
    };

    initMap();
  }, [googleMapsApiKey, mapData]);

  // Firebase real-time data subscription
  useEffect(() => {
    const dataRef = ref(database, 'urbanReports');
    
    console.log('Attempting to connect to Firebase...');
    
    const unsubscribe = onValue(dataRef, (snapshot) => {
      console.log('Firebase connection successful!');
      if (snapshot.exists()) {
        console.log('Data received from Firebase:', snapshot.val());
        const data = snapshot.val();
        const formattedData: UrbanReport[] = Object.keys(data).map(key => ({
          id: key,
          ...data[key],
          // Convert timestamp strings back to Date objects
          request: {
            ...data[key].request,
            reported_at_timestamp: data[key].request.reported_at_timestamp ? 
              new Date(data[key].request.reported_at_timestamp) : undefined
          },
          report_metadata: {
            ...data[key].report_metadata,
            reported_at_timestamp: new Date(data[key].report_metadata.reported_at_timestamp)
          },
          holistic_summary: {
            ...data[key].holistic_summary,
            start_timestamp: new Date(data[key].holistic_summary.start_timestamp),
            end_timestamp: new Date(data[key].holistic_summary.end_timestamp)
          }
        }));
        setMapData(formattedData);
      } else {
        console.log('No data exists in Firebase, using demo data');
        // Keep using demo data if Firebase is empty
      }
    }, (error) => {
      console.error('Firebase connection failed:', error);
      console.log('Using demo data instead');
      // Demo data is already set in useState, so no action needed
    });

    return () => {
      off(dataRef, 'value', unsubscribe);
    };
  }, []);

  const handleApiKeySubmit = (apiKey: string) => {
    setGoogleMapsApiKey(apiKey);
    setIsLoading(true);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    console.log('Searching for:', query);
  };

  // Show API key input if no key is available
  if (!googleMapsApiKey) {
    return <ApiKeyInput onApiKeySubmit={handleApiKeySubmit} />;
  }

  return (
    <div className="relative w-full h-screen bg-background overflow-hidden">
      {/* Map container */}
      <div ref={mapContainer} className="absolute inset-0" />
      
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-40">
          <div className="flex items-center gap-3 bg-surface-elevated rounded-lg px-6 py-4 shadow-floating">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
            <span className="text-foreground font-medium">Loading Google Maps...</span>
          </div>
        </div>
      )}
      
      {/* Map pins overlay - only show if map is loaded */}
      {!isLoading && (
        <div className="absolute inset-0 pointer-events-none z-30">
          {/* Legacy overlay pins disabled for Google Maps */}
        </div>
      )}
      
      {/* Search input */}
      <SearchInput onSearch={handleSearch} />
      
      {/* Live Events Panel */}
      <div className="absolute top-24 left-6 right-6 md:right-auto bg-surface-glass backdrop-blur-lg rounded-xl shadow-soft border border-border/50 z-40 max-w-md md:w-96">
        {/* Header */}
        <div className="px-4 py-3 border-b border-border/50 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">Bengaluru Live</h1>
            <p className="text-sm text-muted-foreground">
              {mapData.length} active events • Updated real-time
            </p>
          </div>
          <button
            onClick={() => setIsEventsExpanded(!isEventsExpanded)}
            className="p-2 hover:bg-surface-elevated rounded-lg transition-colors"
            aria-label={isEventsExpanded ? "Collapse events" : "Expand events"}
          >
            {isEventsExpanded ? (
              <ChevronUp className="w-4 h-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            )}
          </button>
        </div>
        
        {/* Events List */}
        {isEventsExpanded && (
          <div className="max-h-64 md:max-h-96 overflow-y-auto">
          {mapData.map((report, index) => {
            const timeAgo = Math.floor((Date.now() - report.holistic_summary.start_timestamp.getTime()) / 1000 / 60);
            const priorityColor = getPriorityColor(report.holistic_summary.report_priority);
            
            return (
              <div 
                key={report.id}
                className="px-4 py-3 border-b border-border/20 last:border-b-0 hover:bg-surface-elevated/50 cursor-pointer transition-colors"
                onClick={() => {
                  // Focus on the map location when clicked
                  if (map.current && report.holistic_summary.locations.length > 0) {
                    const location = report.holistic_summary.locations[0];
                    map.current.panTo({ lat: location.latitude, lng: location.longitude });
                    map.current.setZoom(15);
                  }
                }}
              >
                <div className="flex items-start gap-3">
                  {/* Priority indicator */}
                  <div className={`w-3 h-3 rounded-full ${priorityColor} mt-1 flex-shrink-0`} />
                  
                  <div className="flex-1 min-w-0">
                    {/* Title and Priority */}
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-sm text-foreground truncate">
                        {report.holistic_summary.title}
                      </h3>
                      <span className={`px-2 py-0.5 text-xs rounded-full ${priorityColor} text-white flex-shrink-0`}>
                        {report.holistic_summary.report_priority}
                      </span>
                    </div>
                    
                    {/* Details */}
                    <p className="text-xs text-muted-foreground mb-2 overflow-hidden" 
                       style={{ 
                         display: '-webkit-box',
                         WebkitLineClamp: 2,
                         WebkitBoxOrient: 'vertical' as any
                       }}>
                      {report.holistic_summary.details}
                    </p>
                    
                    {/* Metadata row */}
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-current rounded opacity-60" />
                        {report.report_metadata.source_type}
                      </span>
                      <span>{timeAgo}m ago</span>
                      {report.holistic_summary.location_names.length > 0 && (
                        <span className="truncate">
                          📍 {report.holistic_summary.location_names[0]}
                        </span>
                      )}
                    </div>
                    
                    {/* Topics */}
                    {report.holistic_summary.topics.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {report.holistic_summary.topics.slice(0, 3).map((topic) => (
                          <span 
                            key={topic}
                            className="px-2 py-0.5 text-xs bg-surface-elevated rounded text-muted-foreground"
                          >
                            {topic}
                          </span>
                        ))}
                        {report.holistic_summary.topics.length > 3 && (
                          <span className="text-xs text-muted-foreground">
                            +{report.holistic_summary.topics.length - 3} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          
          {mapData.length === 0 && (
            <div className="px-4 py-6 text-center text-muted-foreground">
              <p className="text-sm">No active events</p>
              <p className="text-xs">Reports will appear here in real-time</p>
            </div>
          )}
          </div>
        )}
      </div>
      
      {/* Legend */}
      <div className="absolute top-24 right-6 bg-surface-glass backdrop-blur-lg rounded-xl p-4 shadow-soft border border-border/50 z-40">
        <h3 className="text-sm font-semibold text-foreground mb-3">Live Urban Reports</h3>
        
        {/* Priority Legend */}
        <div className="mb-4">
          <h4 className="text-xs font-medium text-foreground mb-2">Priority Levels</h4>
          <div className="space-y-1">
            {[
              { priority: Priority.HIGH, label: 'High Priority', color: 'bg-red-500' },
              { priority: Priority.MEDIUM, label: 'Medium Priority', color: 'bg-orange-500' },
              { priority: Priority.LOW, label: 'Low Priority', color: 'bg-green-500' },
            ].map(({ priority, label, color }) => (
              <div key={priority} className="flex items-center gap-2 text-xs">
                <div className={`w-3 h-3 rounded-full ${color}`} />
                <span className="text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Source Types */}
        <div>
          <h4 className="text-xs font-medium text-foreground mb-2">Source Types</h4>
          <div className="space-y-1">
            {[
              { source: SourceType.AUTHORITY, label: 'Government/Authority' },
              { source: SourceType.BUSINESS, label: 'Business' },
              { source: SourceType.USER, label: 'Citizen Reports' },
              { source: SourceType.OTHER, label: 'Other Sources' },
            ].map(({ source, label }) => (
              <div key={source} className="flex items-center gap-2 text-xs">
                <div className="w-3 h-3 rounded border border-gray-400" />
                <span className="text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapDashboard; 