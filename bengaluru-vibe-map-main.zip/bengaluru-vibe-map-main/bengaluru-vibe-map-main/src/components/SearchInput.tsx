import { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface SearchInputProps {
  onSearch: (query: string) => void;
  placeholder?: string;
}

const SearchInput = ({ onSearch, placeholder = "Search locations, events... 🌟" }: SearchInputProps) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query.trim());
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    
    // Real-time search for better UX
    if (value.trim()) {
      onSearch(value.trim());
    }
  };

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4">
      <form onSubmit={handleSubmit} className="relative">
        <div className={`
          relative bg-surface-glass backdrop-blur-lg rounded-full border border-border/50
          shadow-floating transition-all duration-300 ease-smooth
          ${isFocused ? 'scale-105 shadow-glow border-primary/50' : ''}
        `}>
          {/* Search icon */}
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
            <Search className={`w-5 h-5 transition-colors duration-300 ${
              isFocused ? 'text-primary' : 'text-muted-foreground'
            }`} />
          </div>
          
          {/* Input field */}
          <Input
            type="text"
            value={query}
            onChange={handleInputChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder={placeholder}
            className="
              pl-12 pr-12 py-4 h-14 bg-transparent border-none rounded-full
              placeholder:text-muted-foreground/70 text-foreground
              focus:ring-0 focus:ring-offset-0 focus-visible:ring-0 focus-visible:ring-offset-0
            "
          />
          
          {/* Location icon */}
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
            <MapPin className={`w-5 h-5 transition-colors duration-300 ${
              query ? 'text-primary' : 'text-muted-foreground/50'
            }`} />
          </div>
        </div>
        
        {/* Floating effect */}
        {isFocused && (
          <div className="absolute inset-0 bg-gradient-primary rounded-full opacity-10 animate-pulse-glow -z-10" />
        )}
      </form>
      
      {/* Quick suggestions */}
      {isFocused && (
        <div className="mt-3 bg-surface-glass backdrop-blur-lg rounded-xl border border-border/50 shadow-floating animate-fade-in overflow-hidden">
          <div className="p-2 space-y-1">
            {['🚦 Traffic near me', '🎉 Events tonight', '⚡ Power outages', '🚌 Bus delays'].map((suggestion, index) => (
              <button
                key={index}
                onClick={() => {
                  setQuery(suggestion);
                  onSearch(suggestion);
                }}
                className="w-full text-left px-3 py-2 rounded-lg text-sm text-muted-foreground hover:bg-surface-overlay hover:text-foreground transition-colors duration-200"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchInput;