import MapDashboard from '@/components/MapDashboard';

const Index = () => {
  return <MapDashboard />;
};

export default Index;
