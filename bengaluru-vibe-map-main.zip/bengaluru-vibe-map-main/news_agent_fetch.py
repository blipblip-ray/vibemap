import requests

API_KEY = '703b935455954ed8861349d648757dd6'  # Replace with your real key
SEARCH_TERM = 'Bengaluru'         # or 'Cyclone', 'Concert', etc.
COUNTRY = 'in'                # ISO country code (e.g., 'us', 'in', 'gb')
CATEGORY = 'general'          # 'business', 'entertainment', 'health', etc.
PAGE_SIZE = 5                # Number of articles per call

def fetch_news(query=SEARCH_TERM):
    url = f"https://newsapi.org/v2/top-headlines"
    params = {
        'q': query,
        'country': COUNTRY,
        'category': CATEGORY,
        'pageSize': PAGE_SIZE,
        'apiKey': API_KEY
    }

    response = requests.get(url, params=params)
    data = response.json()

    if data.get("status") != "ok":
        print("Error fetching news:", data)
        return []

    articles = data["articles"]
    for i, article in enumerate(articles):
        print(f"\n{i+1}. {article['title']}")
        print(f"   {article['description']}")
        print(f"   Source: {article['source']['name']}")
        print(f"   URL: {article['url']}")
        print(f"   Published At: {article['publishedAt']}")

    return articles

# Example run
fetch_news()
